package project_demo_pi;

import javax.swing.*;
import java.awt.*;
import java.sql.*;
import java.util.ArrayList;

public class MainFrame extends JFrame {
    private JPanel postsPanel;
    private JScrollPane scrollPane;

    public MainFrame() {
        setTitle("Publicaciones");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 300);

        // Inicializar el panel y el JScrollPane
        postsPanel = new JPanel();
        postsPanel.setLayout(new BoxLayout(postsPanel, BoxLayout.Y_AXIS));
        scrollPane = new JScrollPane(postsPanel);

        // Agregar el JScrollPane al JFrame
        getContentPane().add(scrollPane);

        // Obtener las publicaciones de la base de datos y agregarlas al panel
        obtenerPublicacionesDesdeBaseDeDatos();
    }

    private void obtenerPublicacionesDesdeBaseDeDatos() {
        Connection conn = null;
        try {
            // Establecer la conexión con la base de datos Access
            conn = Conexion.getConnection();

            // Consulta para obtener las publicaciones
            String query = "SELECT UsuarioID, Contenido, ArchivoMultimedia, FechaPublicacion FROM Publicaciones";
            PreparedStatement statement = conn.prepareStatement(query);
            ResultSet resultSet = statement.executeQuery();

            // Procesar los resultados y agregar las publicaciones al panel
            while (resultSet.next()) {
                int usuarioId = resultSet.getInt("UsuarioId");
                String contenido = resultSet.getString("Contenido");
                byte[] multimediaBytes = resultSet.getBytes("ArchivoMultimedia");
                String fechaPublicacion = resultSet.getString("FechaPublicacion");

                ImageIcon imagenIcono = null;
                if (multimediaBytes != null && multimediaBytes.length > 0) {
                    // Convertir bytes de imagen a ImageIcon
                    imagenIcono = new ImageIcon(multimediaBytes);
                    Image imagen = imagenIcono.getImage(); // Convertir a Image
                    // Escalar la imagen para que se ajuste al JLabel
                    Image imagenEscalada = imagen.getScaledInstance(100, 100, java.awt.Image.SCALE_SMOOTH);
                    imagenIcono = new ImageIcon(imagenEscalada);
                }
                
                JPanel panelPublicacion = new JPanel();
                panelPublicacion.setLayout(new BoxLayout(panelPublicacion, BoxLayout.Y_AXIS));
                panelPublicacion.setBorder(BorderFactory.createLineBorder(Color.BLACK));

                JLabel labelUsuario = new JLabel("Usuario ID: " + usuarioId);
                JLabel labelContenido = new JLabel("Contenido: " + contenido);
                JLabel labelMultimedia = new JLabel(imagenIcono); // Usar el ImageIcon con la imagen escalada
                JLabel labelFecha = new JLabel("Fecha de publicación: " + fechaPublicacion);

                panelPublicacion.add(labelUsuario);
                panelPublicacion.add(labelContenido);
               if (imagenIcono != null) {
                panelPublicacion.add(labelMultimedia); // Agregar el JLabel solo si la imagenIcono no es null
            }
            panelPublicacion.add(labelFecha);

            postsPanel.add(panelPublicacion);
        }
    } catch (SQLException e) {
        e.printStackTrace();
    } finally {
        // Cerrar la conexión al finalizar
        if (conn != null) {
            try {
                conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
}


