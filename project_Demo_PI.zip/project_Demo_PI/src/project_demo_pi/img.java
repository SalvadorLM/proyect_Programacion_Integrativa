package project_demo_pi;

import javax.swing.*;
import java.awt.*;
import java.sql.*;
import java.util.Arrays;

public class img extends javax.swing.JFrame {

    /**
     * Creates new form imegen
     */
    public img() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLblImagen = new javax.swing.JLabel();
        insert = new javax.swing.JButton();
        Extract = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLblImagen.setText("Imagen");

        insert.setText("Insertar imagen ");
        insert.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                insertActionPerformed(evt);
            }
        });

        Extract.setText("Extraer Imagen");
        Extract.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ExtractActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLblImagen, javax.swing.GroupLayout.DEFAULT_SIZE, 349, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(24, 24, 24)
                        .addComponent(insert)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(Extract)))
                .addGap(45, 45, 45))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(47, 47, 47)
                .addComponent(jLblImagen, javax.swing.GroupLayout.DEFAULT_SIZE, 158, Short.MAX_VALUE)
                .addGap(55, 55, 55)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(insert)
                    .addComponent(Extract))
                .addGap(17, 17, 17))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void insertActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_insertActionPerformed
        
        byte[] img=Manejador.leerImagen();
        
        Connection conn = Conexion.getConnection();
        String query = "INSERT INTO Imagenes (img) VALUES (?)";
        
        try {
           PreparedStatement statement = conn.prepareStatement(query);
            // Supongamos que estos datos vienen de algún lugar en tu aplicación 
            statement.setBytes(1, img);
           
            statement.executeUpdate();
            statement.close();
            conn.close();
            
            System.out.println("Publicación insertada correctamente en la base de datos.");
        } catch (SQLException e) {
            // Manejar cualquier excepción que pueda ocurrir al ejecutar la consulta SQL
            e.printStackTrace();
        }
    }//GEN-LAST:event_insertActionPerformed

    private void ExtractActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ExtractActionPerformed
       Connection conn = null;
        try {
            // Establecer la conexión con la base de datos Access
            conn = Conexion.getConnection();

            // Consulta para obtener la imagen con el ID especificado
            String query = "SELECT img FROM imagenes WHERE ID = ?";
            PreparedStatement statement = conn.prepareStatement(query);
            statement.setInt(1, 1); // Reemplaza 2 con el ID específico que deseas recuperar
            ResultSet resultSet = statement.executeQuery();

            // Procesar los resultados y mostrar la imagen en el JLabel
            if (resultSet.next()) {
                byte[] multimediaBytes = resultSet.getBytes("img");
                System.out.println("Datos de imagen obtenidos de la base de datos:");
                System.out.println(Arrays.toString(multimediaBytes));
                ImageIcon imagenIcono = null;
                if (multimediaBytes != null && multimediaBytes.length > 0) {
                    // Convertir bytes de imagen a ImageIcon
                    imagenIcono = new ImageIcon(multimediaBytes);
                    Image imagen = imagenIcono.getImage(); // Convertir a Image
                    // Escalar la imagen para que se ajuste al JLabel
                    Image imagenEscalada = imagen.getScaledInstance(100, 100, java.awt.Image.SCALE_SMOOTH);
                    imagenIcono = new ImageIcon(imagenEscalada);
                }
                
                jLblImagen.setIcon(imagenIcono); // Usar el ImageIcon con la imagen escalada
            } else {
                JOptionPane.showMessageDialog(null, "No se encontró ninguna imagen con el ID especificado.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            // Cerrar la conexión al finalizar
            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }//GEN-LAST:event_ExtractActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(img.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(img.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(img.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(img.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new img().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Extract;
    private javax.swing.JButton insert;
    private javax.swing.JLabel jLblImagen;
    // End of variables declaration//GEN-END:variables
}
