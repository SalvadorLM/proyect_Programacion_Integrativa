package project_demo_pi;

import javax.swing.*;

public class main {

    public static void main(String[] args) {
    SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                MainFrame frame = new MainFrame();
                frame.setVisible(true);
            }
        });
    }
}
