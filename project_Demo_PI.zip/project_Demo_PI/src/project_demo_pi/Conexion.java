package project_demo_pi;

import java.sql.*;

public class Conexion {
    private static Connection conn;

    // Método para establecer la conexión a la base de datos
    public static Connection getConnection() {
        if (conn == null) {
            try {
                // Establecer la conexión a la base de datos de Access utilizando UCanAccess
                String url = "jdbc:ucanaccess://C:\\Users\\salva\\OneDrive\\Documentos\\NetBeansProjects\\project_Demo_PI\\BD_publicacion.accdb";
                conn = DriverManager.getConnection(url);
            } catch (SQLException e) {
                System.err.println("Error al establecer la conexión: " + e.getMessage());
                e.printStackTrace();
            }
        }
        return conn;
    }

    // Método para cerrar la conexión
    public static void closeConnection() {
        if (conn != null) {
            try {
                conn.close();
                System.out.println("Conexión cerrada correctamente.");
            } catch (SQLException e) {
                System.err.println("Error al cerrar la conexión: " + e.getMessage());
                e.printStackTrace();
            }
        }
    }
}