package project_demo_pi;
import java.util.Date;

public class Publicacion {

    private int id;
    private int usuarioId;
    private String contenido;
    private byte[] archivoMultimedia;
    private Date fechaPublicacion;

    // Constructor
    public Publicacion(int id, int usuarioId, String contenido, byte[] archivoMultimedia, Date fechaPublicacion) {
        this.id = id;
        this.usuarioId = usuarioId;
        this.contenido = contenido;
        this.archivoMultimedia = archivoMultimedia;
        this.fechaPublicacion = fechaPublicacion;
    }

    // Getters y setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getUsuarioId() {
        return usuarioId;
    }

    public void setUsuarioId(int usuarioId) {
        this.usuarioId = usuarioId;
    }

    public String getContenido() {
        return contenido;
    }

    public void setContenido(String contenido) {
        this.contenido = contenido;
    }

    public byte[] getArchivoMultimedia() {
        return archivoMultimedia;
    }

    public void setArchivoMultimedia(byte[] archivoMultimedia) {
        this.archivoMultimedia = archivoMultimedia;
    }

    public Date getFechaPublicacion() {
        return fechaPublicacion;
    }

    public void setFechaPublicacion(Date fechaPublicacion) {
        this.fechaPublicacion = fechaPublicacion;
    }
}
